// SPDX-FileCopyrightText: 2024-2026 DigiGaia SCCL
// SPDX-License-Identifier: AGPL-3.0-or-later

pub const VERSION: &str = include_str!(concat!(env!("OUT_DIR"), "/version"));

pub const BLOCK_INTERVAL_MS: u16 = 500;
pub const BLOCK_TIMESTAMP_EPOCH: u64 = 946_684_800_000; // epoch in ms, corresponds to 2000-01-01

pub const VAULTA_FEATURES: &[(&str, &str)] = &[
    ("GET_CODE_HASH",                    "bcd2a26394b36614fd4894241d3c451ab0f6fd110958c3423073621a70826e99"),
    ("CRYPTO_PRIMITIVES",                "6bcb40a24e49c26d0a60513b6aeb8551d264e4717f306b81a37a5afb3b47cedc"),
    ("GET_BLOCK_NUM",                    "35c2186cc36f7bb4aeaf4487b36e57039ccf45a9136aa856a5d569ecca55ef2b"),
    ("ACTION_RETURN_VALUE",              "c3a6138c5061cf291310887c0b5c71fcaffeab90d5deb50d3b9e687cead45071"),
    ("CONFIGURABLE_WASM_LIMITS2",        "d528b9f6e9693f45ed277af93474fd473ce7d831dae2180cca35d907bd10cb40"),
    ("BLOCKCHAIN_PARAMETERS",            "5443fcf88330c586bc0e5f3dee10e7f63c76c00249c87fe4fbf7f38c082006b4"),
    ("GET_SENDER",                       "f0af56d2c5a48d60a4a5b5c903edfb7db3a736a94ed589d0b797df33ff9d3e1d"),
    ("FORWARD_SETCODE",                  "2652f5f96006294109b3dd0bbde63693f55324af452b799ee137a81a905eed25"),
    ("ONLY_BILL_FIRST_AUTHORIZER",       "8ba52fe7a3956c5cd3a656a3174b931d3bb2abb45578befc59f283ecd816a405"),
    ("RESTRICT_ACTION_TO_SELF",          "ad9e3d8f650687709fd68f4b90b41f7d825a365b02c23a636cef88ac2ac00c43"),
    ("DISALLOW_EMPTY_PRODUCER_SCHEDULE", "68dcaa34c0517d19666e6b33add67351d8c5f69e999ca1e37931bc410a297428"),
    ("FIX_LINKAUTH_RESTRICTION",         "e0fb64b1085cc5538970158d05a009c24e276fb94e1a0bf6a528b48fbc4ff526"),
    ("REPLACE_DEFERRED",                 "ef43112c6543b88db2283a2e077278c315ae2c84719a8b25f25cc88565fbea99"),
    ("NO_DUPLICATE_DEFERRED_ID",         "4a90c00d55454dc5b059055ca213579c6ea856967712a56017487886a4d4cc0f"),
    ("ONLY_LINK_TO_EXISTING_PERMISSION", "1a99a59d87e06e09ec5b028a9cbb7749b4a5ad8819004365d02dc4379a8b7241"),
    ("RAM_RESTRICTIONS",                 "4e7bf348da00a945489b2a681749eb56f5de00b900014e137ddae39f48f69d67"),
    ("WEBAUTHN_KEY",                     "4fca8bd82bbd181e714e283f83e1b45d95ca5af40fb89ad3977b653c448f78c2"),
    ("WTMSIG_BLOCK_SIGNATURES",          "299dcb6af692324b899b39f16d5a530a33062804e41f09dc97e9f156b4476707"),
    ("BLS_PRIMITIVES2",                  "63320dd4a58212e4d32d1f58926b73ca33a247326c2a5e9fd39268d2384e011a"),
    ("DISABLE_DEFERRED_TRXS_STAGE_1",    "fce57d2331667353a0eac6b4209b67b843a7262a848af0a49a6e2fa9f6584eb4"),
    ("DISABLE_DEFERRED_TRXS_STAGE_2",    "09e86cb0accf8d81c9e85d34bea4b925ae936626d00c984e4691186891f5bc16"),
    ("SAVANNA",                          "cbe0fafc8fcc6cc998395e9b6de6ebd94644467b1b4a97ec126005df07013c52"),
];

pub const VAULTA_CHAIN_ID: &str = "aca376f206b8fc25a6ed44dbdc66547c36c6c33e3a119ffbeaef943642f0e906";
pub const JUNGLE_CHAIN_ID: &str = "73e4385a2708e6d7048834fbc1079f2fabb17b3c125b146af438971e90716c4d";


// -----------------------------------------------------------------------------
//     Security constants
//
// These constants are here to ensure that execution time, memory allocation,
// stack depth, etc. are bounded to avoid respectively infinite loops,
// out-of-memory crashes and stack overflows.
//
// -----------------------------------------------------------------------------

// max size for a vector/array that we deserialize from a binary stream
pub const MAX_ARRAY_SIZE: usize = 1_000_000;
